#include "user_config.h"
#include "user_event.h"
#include "user_gpio.h"
#include "user_player.h"
#include "user_pwm.h"
#include "user_timer.h"
#include "user_uart.h"

#define TAG "auto_gpio"

#define UART_SEND_MAX      16

typedef struct {
  char  data[UART_SEND_MAX];
  int   len;
}uart_data_t;

const uart_data_t g_uart_buf[] = {
  {{0x10}, 1}, //Manual_Mode
  {{0x20}, 1}, //Obstacle_Avoid
  {{0x30}, 1}, //Tarck
  {{0x11}, 1}, //MoveForward
  {{0x12}, 1}, //MoveBackward
  {{0x16}, 1}, //Self_Left
  {{0x15}, 1}, //Self_Right
  {{0x14}, 1}, //Turn_Left
  {{0x13}, 1}, //Turn_Right
  {{0x17}, 1}, //Car_Stop
  {{0x18}, 1}, //Rest
  {{0x19}, 1}, //KeepRight
  {{0x41}, 1}, //KeepForward
  {{0x42}, 1}, //Count
};

static void _custom_setting_cb(USER_EVENT_TYPE event,
                               user_event_context_t *context) {
  event_custom_setting_t *setting = NULL;
  if (context) {
    setting = &context->custom_setting;
    LOGT(TAG, "user command: %s", setting->cmd);
    if (0 == uni_strcmp(setting->cmd, "Manual_Mode")) {
      user_uart_send(g_uart_buf[0].data, g_uart_buf[0].len);
    } else if (0 == uni_strcmp(setting->cmd, "Obstacle_Avoid")) {
      user_uart_send(g_uart_buf[1].data, g_uart_buf[1].len);
    } else if (0 == uni_strcmp(setting->cmd, "Tarck")) {
      user_uart_send(g_uart_buf[2].data, g_uart_buf[2].len);
    } else if (0 == uni_strcmp(setting->cmd, "MoveForward")) {
      user_uart_send(g_uart_buf[3].data, g_uart_buf[3].len);
    } else if (0 == uni_strcmp(setting->cmd, "MoveBackward")) {
      user_uart_send(g_uart_buf[4].data, g_uart_buf[4].len);
    } else if (0 == uni_strcmp(setting->cmd, "Self_Left")) {
      user_uart_send(g_uart_buf[5].data, g_uart_buf[5].len);
    } else if (0 == uni_strcmp(setting->cmd, "Self_Right")) {
      user_uart_send(g_uart_buf[6].data, g_uart_buf[6].len);
    } else if (0 == uni_strcmp(setting->cmd, "Turn_Left")) {
      user_uart_send(g_uart_buf[7].data, g_uart_buf[7].len);
    } else if (0 == uni_strcmp(setting->cmd, "Turn_Right")) {
      user_uart_send(g_uart_buf[8].data, g_uart_buf[8].len);
    } else if (0 == uni_strcmp(setting->cmd, "Car_Stop")) {
      user_uart_send(g_uart_buf[9].data, g_uart_buf[9].len);
    } else if (0 == uni_strcmp(setting->cmd, "Rest")) {
      user_uart_send(g_uart_buf[10].data, g_uart_buf[10].len);
    } else if (0 == uni_strcmp(setting->cmd, "KeepRight")) {
      user_uart_send(g_uart_buf[11].data, g_uart_buf[11].len);
    } else if (0 == uni_strcmp(setting->cmd, "KeepForward")) {
      user_uart_send(g_uart_buf[12].data, g_uart_buf[12].len);
    } else if (0 == uni_strcmp(setting->cmd, "Count")) {
      user_uart_send(g_uart_buf[13].data, g_uart_buf[13].len);
    } else {
      LOGT(TAG, "Unconcerned command: %s", setting->cmd);
    }
    user_player_reply_list_random(setting->reply_files);
  }
}

static void _register_event_callback(void) {
  user_event_subscribe_event(USER_CUSTOM_SETTING, _custom_setting_cb);
}

int hb_auto_gpio(void) {
  user_gpio_init();
  user_gpio_set_mode(GPIO_NUM_A25, GPIO_MODE_OUT);
  user_gpio_set_value(GPIO_NUM_A25, 0);
  user_gpio_set_mode(GPIO_NUM_A26, GPIO_MODE_OUT);
  user_gpio_set_value(GPIO_NUM_A26, 0);
  user_gpio_set_mode(GPIO_NUM_A27, GPIO_MODE_OUT);
  user_gpio_set_value(GPIO_NUM_A27, 0);
  user_gpio_set_mode(GPIO_NUM_A28, GPIO_MODE_OUT);
  user_gpio_set_value(GPIO_NUM_A28, 0);
  user_gpio_set_mode(GPIO_NUM_B2, GPIO_MODE_OUT);
  user_gpio_set_value(GPIO_NUM_B2, 0);
  user_gpio_set_mode(GPIO_NUM_B3, GPIO_MODE_OUT);
  user_gpio_set_value(GPIO_NUM_B3, 0);
  user_uart_init(NULL);
  _register_event_callback();
  return 0;
}

