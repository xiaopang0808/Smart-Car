#ifndef INC_UNI_CMD_CODE_H_
#define INC_UNI_CMD_CODE_H_

typedef struct {
  uni_u8      cmd_code; /* cmd code fro send base on SUCP */
  const char  *cmd_str; /* action string on UDP */;
} cmd_code_map_t;

const cmd_code_map_t g_cmd_code_arry[] = {
  {0x0, "wakeup_uni"},
  {0x1, "exitUni"},
  {0x2, "Manual_Mode"},
  {0x3, "Obstacle_Avoid"},
  {0x4, "Tarck"},
  {0x5, "MoveForward"},
  {0x6, "MoveBackward"},
  {0x7, "Self_Left"},
  {0x8, "Self_Right"},
  {0x9, "Turn_Left"},
  {0xa, "Turn_Right"},
  {0xb, "Car_Stop"},
  {0xc, "Rest"},
  {0xd, "KeepRight"},
  {0xe, "KeepForward"},
  {0xf, "Count"},
  {0x10, "startStudy"},
  {0x11, "clearStudy"},
  {0x12, "clearStuCmd"},
  {0x13, "clearStuWakeup"},
  {0x14, "startStuWakeup"},
  {0x15, "startStuCmd"},
};

#endif
